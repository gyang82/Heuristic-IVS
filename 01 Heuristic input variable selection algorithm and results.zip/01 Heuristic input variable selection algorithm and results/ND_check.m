function [ND_set, dominance_flag] = ND_check(ND_set, Y, X)
dominance_flag = 0;
num_objs = length(Y);
i=0; 
while i < size(ND_set, 1)
    i = i + 1;
    num_eql = sum(Y == ND_set(i, 1 : num_objs));
    num_imp = sum(Y < ND_set(i, 1 : num_objs));
    num_deg = sum(Y > ND_set(i, 1 : num_objs));
    if (num_imp == 0) && (num_deg > 0)
        dominance_flag = -1; 
        return;
    elseif num_eql == num_objs 
        ND_set(i,:) = [Y X];
        dominance_flag = 0; 
        return;
    elseif num_imp > 0 && num_deg == 0
        ND_set(i,:) = []; 
        dominance_flag = 1;
        ND_set(size(ND_set, 1) + 1, :) = [Y X];
        return;
    end
end
if isempty(ND_set)
    ND_set = [Y X];
else 
    ND_set(size(ND_set, 1) + 1, :) = [Y X];
end