function [a]=calrbfs(maxzn)
global x y numRBFNeurons normalize beta PN2 TN2 N2 TN1 N1 N;
% addpath('kMeans');
% addpath('RBFN');
% maxzn=[1 3 5 7];
xx=x(:,[maxzn(1:end-2)]);
numRBFNeuronss=maxzn(end-1);
% numRBFNeuronss=4;
sigma = maxzn(end);
% Compute the beta value from sigma.
beta = 1 ./ (2 .* sigma.^2);
% numRBFNeuronss=
[Centers, betas, Theta] = trainFuncApproxRBFN(xx, y, numRBFNeuronss, normalize, beta, true);
%%
xs = xx;
ys = zeros(size(xs,1),1);
for i = 1:N

	% Evaluate the RBFN at the query point xs(i) and store the result in ys(i).
	ys(i) = evaluateFuncApproxRBFN(Centers, betas, Theta, normalize, xs(i,:));
end
a= Rt2_fit(TN1',ys,numRBFNeuronss,size(xx,2),1115);







%%
% xs = PN2';
% xs=xs(:,[maxzn(1:end-1)]);
% ys = zeros(size(xs,1),1);
% for i = 1:N2
% 
% 	% Evaluate the RBFN at the query point xs(i) and store the result in ys(i).
% 	ys(i) = evaluateFuncApproxRBFN(Centers, betas, Theta, normalize, xs(i,:));
% 	
% end
% a= Rt2_fit(TN2',ys);
end