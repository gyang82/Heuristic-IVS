function [a]=calrbfs(maxzn)
global x y numRBFNeurons normalize beta PN2 TN2 N2 TN1 N1;
% addpath('kMeans');
% addpath('RBFN');
% maxzn=[1 3 5 7];
xx=x(:,[maxzn(1:end-1)]);
numRBFNeuronss=maxzn(end);
ns=3;
a = crossvalidation_rbf([xx y],numRBFNeuronss,normalize,beta,ns);


%%
% xs = PN2';
% xs=xs(:,[maxzn(1:end-1)]);
% ys = zeros(size(xs,1),1);
% for i = 1:N2
% 
% 	% Evaluate the RBFN at the query point xs(i) and store the result in ys(i).
% 	ys(i) = evaluateFuncApproxRBFN(Centers, betas, Theta, normalize, xs(i,:));
% 	
% end
% a= Rt2_fit(TN2',ys);
end