

function [nlen]=MainPADDS()
addpath('kMeans');
addpath('RBFN');

%%
global  P1 P2 T1 T2 x y sigma beta normalize PN2 TN2 N2 numRBFNeurons TN1 N;
global mint maxt;

%clc
% clear
% close all
% data2=importdata('datas.mat');
data2=importdata('data_P_qout.mat');
[m,n]=size(data2);
% 
% px1=randperm(m);
px1=1:m;

data1=data2(px1,:);
% data=data1(:,[1:7,12,13,end]);
data=data1(:,[1:13,end]);
% Re-define the subset matrix

% lag=4;
% for lag=2:9
% yy=zeros(length(data),lag+4)
% yy(:,lag+1:end)=data;
% yy(:,1:lag)=data(:,1)*ones(1,lag);
% for i=1:lag
%     yy(i+1:end,i)=yy(1:end-i,i);
% end
% datas=yy;
% % data=yy;
% mult_runs=2;
% for i = 1:mult_runs
%     eval(['Da' num2str(i) '=' 'shuffle_data(data);']);
% end


% subset=Da1;
subset=data;
ns=5;
l = floor(length(subset)/ns);
subset = subset(1:l*ns,:);




P1=subset(1:l*(ns-1),1:end-1)';        
T1=subset(1:l*(ns-1),end)';            

P2=subset(l*(ns-1)+1:l*(ns),1:end-1)';        
T2=subset(l*(ns-1)+1:l*(ns),end)';        

% [PN1,minp,maxp,TN1,mint,maxt] = premnmx(P1,T1);
[PN1,minp,maxp,TN1,mint,maxt] = premnmx(subset(:,1:end-1)',subset(:,end)');
PN2 = tramnmx(P2,minp,maxp);
TN2 = tramnmx(T2,mint,maxt);
N2=length(TN2);
N1=length(TN1);
% Define the input range x.
% x = [1:100]'; 
x=PN1';
y=TN1';
kk=1;
% numRBFNeurons=20;
% sigma = sqrt(size(x,2))*2/(numRBFNeurons^(1/size(x,2)));
% Compute the beta value from sigma.
% beta = 1 ./ (2 .* sigma.^2);

% 2. Specify whether to normalize the RBF neuron activations.
normalize = true;

N=length(x);

%% IMPORTANT USER NOTES 
% Written by Bryan Tolson - Jan 2003 to Dec 2004...
% Modified by MAsadzadeh Ocotber 2013 to archive results of MO version of DDS called PADDS

% This is the main Pareto Archived Dynamically Dimensioned Search (DDS)
% algorithm *calling* program for running the PADDS algorithm multiple
% times on a single problem.
% Program is for calling and accumulating MULTIPLE optimization trial
% results of the PADDS algorithm. 
% This code can be succesfully executed from the Matlab command prompt.

% General program for either MAX or MIN objectives
%   A) matlab function coded as an m file OR
%   B) compiled model exe (i.e. a simulation model like SWAT) that is located in a subdirectory within the
%   current directory.
%   In case A), the .m function must accept as input argument the decision variable values and return
%   as the value of objective functions.  Similar idea
%   in case B) except that the DDS algorithm calls a feval function that
%   communicates with the compiled exe file you are trying to run.

% Program requires TWO input files from the USER:
%   1.  Algorithm input control file called 'DDS_inp.txt'
%       See this file and comments below for input descriptions.
%   2.  Objective or cost function decision variable description file
%       called 'strcat(objfunc_name,'.inp')' where the objfunc_name variable
%       is the name of the function that returns the objective function
%       value to the DDS optimization algorithm. 1 headerline, then column
%       1 is decision variable names, column 2 is the lower bounds, column
%       3 is the upper bounds, and column 4 is the discrete flag= 0: real; 1: discrete DV.

% Saves trial outputs to multiple files
% - user picks amount of data (#files) saved.  Algorithm saves
% non-dominated solutions and non-dominated points (objective space)
% for all iterations of all optimization trials as well as the algorithm
% inputs so that the results can be replicated exactly.

% FUNCTIONS CALLED by this program:
% DDS.m  - main DDS algorithm code for one trial.
% bounds.m - reads in decision variable info from the 'strcat(objfunc_name,'.inp')' file.
% read_DDS_inp.m - reads the DDS algorithm inputs from the DDS_inp.txt file.
% All other .m files in this directory are called by one or more of the
% above functions and include neigh_value_mixed.m.
%% NEW APPLICATION
% Modify DDS_inp.txt :
%  Line3 : objfunc_name - name of objective function main file
%  Line4 : runname - short name used to create output files and folder
%  Line5 : num_trials - number of independent optimization trials to run
%  Line6 : maxiter - maximum number of iterations or function calls in each optimization trial. PA-DDS Always runs to maximum iterations.
%  Line7 & 8: user_seeds - 2 number seeds between 1 and 10^9 to fix random # generator state.
%  Line9 : out_plot - 0: do not plot tradeoff; 1: plot tradeoff
%  Line10: ini_name - name of file containing initial solutions. Each row
%           is one solution. If OBJ values are known for these solutions
%           have OBJ first in each row then the solution DVs.
%  Line11: model_subdir - the full path name of the directory that contains
%           the main file for calculating objective function values.
%  Line14: obj_flag - flags for each objective: -1: maximize, 1: minimize objective
%  Line15: fraction1 - std dev/DV range to determine variance of normal perturbation.
%  Line16: selection metric - 0: Random, 1: Crowding distance, 2: Hypervolume Contribution, 3: ConvexHull Contribution
%% DEFINE GLOBAL VARIABLES
global objfunc_name; % function name that returns the objective function values
global S_name; % decision variable names
global S_min;  % decision variable minimums
global S_max;  % decision variable maximums
global Discrete_flag; % decision variable discrete flag= 0 or 1
global num_dec;
global num_objs; %added by masoud 08/05/08
global PF_set; % Set of all archived non-dominated points and solutions 

global Modeldir; % simulation model directory if used
global codedir; % current directory containing this code
global trial_num; % number of current trial running so your cost function can  
                  % know this for for saving supplemental model run outputs in unique files.
codedir = pwd;
%% Screen message:
diary off;
if exist('screen.capt', 'file')
    delete('screen.capt');
end
diary('screen.capt');
diary 'on';
fprintf('\n\n');
fprintf('------------- PADDS Optimization Algorithm Main Program ------------- \n\n');
%% Gather USER PROGRAM inputs:
[objfunc_name, runname, obj_flag, num_trials, maxiter, user_seeds, fraction1, ...
        out_plot, ini_soln, ini_name, model_subdir, Select_metric] = read_DDS_inp([]);
if isempty(model_subdir)
    Modeldir = codedir;
elseif isempty(strfind(model_subdir,':\'))  % ':\' not found --> a subdirectory entered
    Modeldir = strcat(codedir,'\',model_subdir);
else  % new option, ':\' found:
    Modeldir = model_subdir;  % absolute path entered in input file
end    
%% call the bounds program to return decision variable bounds:
bounds; %Reads DV bounds from *.inp file in the model directory
S_name = char(S_name);
num_dec = length(S_min);
num_objs = length (obj_flag);
% ALGORITHM AND OUTPUT OPERATE with S = [ # # # #] -> row vectors of decision variables:
S_min = S_min';
S_max = S_max';
Discrete_flag = Discrete_flag'; % 1: discrete; 0: real variable
%% Initial solution coding:
Initial_mat = [];
if ini_soln == 0 % user didn't define initial solution
    num_samples = max(5, round(0.005 * maxiter)); % try 5 or more MCS samples *******
elseif ini_soln == 1 % user has defined starting solutions already, get all initials
    Initial_mat = importdata(ini_name);
    num_samples = 1; % assume 1st solution "counts"
end
%% Input error checking:
if prod(obj_flag) ~= -1 && prod(obj_flag) ~= 1  % ***NEW ALGORITHM*** only if your algorithm uses variable obj_flag, else comment if
    error('Please enter -1 or 1 for objective function flag!  Try program again.')
end
if num_trials < 1 || num_trials > 1000
    error('Please enter 1 to 1000 optimization trials!  Try program again.')
end
if out_plot ~= 0 && out_plot ~= 1
    error('Please enter 0 or 1 for output plotting flag! Try program again.')
end
%% Initialize Matlab random generator
% MAsadzadeh 24/10/2013
% See: Replace Discouraged Syntaxes of rand and randn @ link below:
% http://www.mathworks.com/help/matlab/math/updating-your-random-number-generator-syntax.html
rng('default');
uni_state = round(mean(user_seeds));
rng(uni_state); % MAsadzadeh: Initialize both Uniform and Normal
%%   ALGORITHM TRIAL CALLING LOOP
for j = 1 : num_trials 
    trial_num = j;
    fprintf('Trial number %g executing ... \n',j);
    tic;  % time the trial
    % set the initial solution (vector or blank)
    if isempty(Initial_mat)
        Initial = [];
    else
        Initial = Initial_mat;
    end
%% Call DDS
    DDS(Initial, num_samples, fraction1, maxiter, obj_flag, Select_metric, out_plot,num_trials);
    time_trial = toc; %STOP time the trial
    time_trialhr = time_trial/(3600);
    jchar = int2str(j);
    filenam1 = strcat(objfunc_name,'_nondom_pts',jchar,'.out');
    fid1 = fopen(filenam1,'w');
    filenam2 = strcat(objfunc_name,'_nondom_sol',jchar,'.out');
    fid2 = fopen(filenam2,'w');
    fprintf(fid2,'Time of execution for trial %g was %g seconds or %g hours. \n\n',j,time_trial,time_trialhr);
    for k = 1 : size(PF_set,1)
        fprintf(fid1,'%12.6f ',obj_flag.*PF_set(k,1:num_objs));
        fprintf(fid1,'\n');
        fprintf(fid2,'%12.6f ',PF_set(k,num_objs+1:num_dec+num_objs));
        fprintf(fid2,'\n');
    end
    fclose(fid1);
    fclose(fid2);
    if out_plot == 1
        h = gcf;
        file_nam = strcat(objfunc_name, '_PF_', num2str(j), '.fig');
        saveas(h, file_nam);
    end
end % END ALGORITHM TRIAL CALLING LOOP
%% OUTPUT FILE MANAGEMENT:
diary 'off';
switch Select_metric
    case {0}
        outDirName = strcat(runname, '_iter', num2str(maxiter), '_RND');
    case {1}
        outDirName = strcat(runname, '_iter', num2str(maxiter), '_CRD');
    case {2}
        outDirName = strcat(runname, '_iter', num2str(maxiter), '_HVC');
    case {3}
        outDirName = strcat(runname, '_iter', num2str(maxiter), '_CHC');
        delete('stdin.txt', 'stdout.txt');
end
mkdir(outDirName);
tempname = strcat('*.out');  % this statement saves all *.out files
opt_out_files = dir(tempname);
for i = 1 : length(opt_out_files)
    movefile(opt_out_files(i).name, outDirName)
end
tempname = strcat('*.fig');  % this statement saves all *.out files
opt_out_files = dir(tempname);
for i = 1 : length(opt_out_files)
    movefile(opt_out_files(i).name, outDirName)
end
tempname = strcat('*.mat');  % this statement delete all *.mat files that temporarily save the results in case of the crash in the run
opt_out_files = dir(tempname);
for i = 1 : length(opt_out_files)
    delete(opt_out_files(i).name);
end
cd(Modeldir);
file = strcat(objfunc_name,'.inp');
tmp = strcat(codedir, '\', outDirName);
copyfile(file, tmp, 'f');
cd(codedir);
copyfile('DDS_inp.txt', outDirName, 'f')
movefile('screen.capt', outDirName);
% done output file mgt
fprintf('MainPADDS Program finished.  See output files in %s directory.\n\n', outDirName);

end