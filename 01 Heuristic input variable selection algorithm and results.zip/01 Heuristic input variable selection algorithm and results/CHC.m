function CHC_metric = CHC(points)
%% Comments
% Written by Masoud Asadzadeh, University of Waterloo, June 03 2011

% This code calls the compiled executable file called qhull.exe in the MS Windows platform. 
% See http://www.qhull.org/ for the source code of qhull.

% This function calculates Convex Hull Contribution CHC. See: 
% Asadzadeh, M., B. A. Tolson, and D. H. Burn (2014), A new selection metric for multiobjective hydrologic model calibration, Water Resour. Res., 50, 7082�7099, doi:10.1002/2013WR014970. 
  
% There are four mutually exclusive sets of points in CH: 
% i. Points inside the convex hull
% ii. Vertices of top facet only
% iii. Vertices of bottom facets only
% iv. Vertices in the intersection of top and bottom facets

% CHC is ZERO for points in i and ii. CHC for points iii is calculated as
% their contribution to the volume of the convex hull of set of "points".
% CHC for points iv is calculated as the CHC of closest point in iii.

% e.g. CHC_metric = CHC([1 10; 2 9.8; 3 5; 4 4; 8 2; 10 1])
%% Normalize the objective space
max_f = max(points, [], 1);
min_f = min(points, [], 1);
MAX_f = repmat(max_f, size(points,1), 1);
MIN_f = repmat(min_f, size(points,1), 1);
points = (points - MIN_f) ./ (MAX_f - MIN_f);
if size(points,1) <= size(points,2) + 1
    CHC_metric = ones(size(points,1),1);
    return;
else
    CHC_metric = zeros(size(points,1),1);
end
%% Caculate the total Convex Hull Volume and facets vertices and norms
Totalv = [];
try
    [Totalv, facets] = callqhull( points );
catch err
    err.message;
end
if isempty(Totalv)
    display('No Convex Hull --> Points are the same');
    CHC_metric = ones(size(points,1),1);
    return;
end
all_CHpts_ind = unique(facets.vertices); % All points that form CH
% If a facet has more than m vertices (m is the number of objectives) other
% facets will have 0 to have the same number of columns. This 0 should be removed.   
ZEROind = all_CHpts_ind == 0; 
all_CHpts_ind(ZEROind) = [];
%% Identify points in groups ii, iii, iv as defined above
top_facets_ind = min(facets.norm, [], 2) >= 0; % facets with outward norm that has only non-negative components
ii_iv_CHpts_ind = unique(facets.vertices(top_facets_ind, :)); % points on top of CH, i.e. groups ii and iv
ZEROind = ii_iv_CHpts_ind == 0; 
ii_iv_CHpts_ind(ZEROind) = [];
other_facets_ind = 1 : size(facets.norm, 1); % All facets
other_facets_ind(top_facets_ind) = []; % Remove top facets
iii_iv_CHpts_ind = unique(facets.vertices(other_facets_ind, :)); % points on bottom of CH, i.e. groups iii and iv
ZEROind = iii_iv_CHpts_ind == 0; 
iii_iv_CHpts_ind(ZEROind) = [];

bor_ind = ismember(iii_iv_CHpts_ind, ii_iv_CHpts_ind); % border points or iv points are at the intersection of top and other facets
bor_CHpts_ind = iii_iv_CHpts_ind(bor_ind);
bot_CHpts_ind = iii_iv_CHpts_ind; 
bot_CHpts_ind(bor_ind) = []; % Remove border points from bottom points
%% When number of bottom points and border points are not enough to form CH
if isempty(bot_CHpts_ind)
    CHC_metric(bot_CHpts_ind) = 1;
    CHC_metric(bor_CHpts_ind) = 1;
    return;
end
%% Convex Hull Contribution Calculation
for i = 1 : length(bot_CHpts_ind)
    y = points(all_CHpts_ind, :); % Only consider points that are on the vertices of convex hull
                                     % Meaning that forget the points inside the convex hull
    ind = ismember(all_CHpts_ind, bot_CHpts_ind(i)); % Remove the bottom points one by one to measure CHC for them
    y(ind, :) = [];
    Sub_v = [];
    try
        [nothing, Sub_v] = convhulln( y ); % convhulln is faster than callqhull because callqhull uses I/O to read facets properties
    catch err
        err.message;
    end
    if isempty(Sub_v) % if error occurs
        CHC_metric = zeros(size(points,1),1);
        CHC_metric(bot_CHpts_ind) = 1;
        CHC_metric(bor_CHpts_ind) = 1;
        return;
    elseif Sub_v > Totalv %just in case of numerical issues
        CHC_metric(bot_CHpts_ind(i)) = 0;
    else
        CHC_metric(bot_CHpts_ind(i)) = Totalv - Sub_v;
    end
end
if max(CHC_metric) == 0 % In case no solution has valid CHC value 
    CHC_metric(bot_CHpts_ind) = 1;
    CHC_metric(bor_CHpts_ind) = 1;
    return;
end
%% CHC for border points
% CHC value of border points is set to the CHC of their closest bottom point
% The reason is that removing the border points drastically shrinks CH from
% the top and therefore that contribution is not consistent with CHC for
% bottom points.
Y = points(bor_CHpts_ind, :);
X = points(bot_CHpts_ind, :);
IDX = dsearchn(X, Y);
for i = 1 : length(bor_CHpts_ind)
    CHC_metric(bor_CHpts_ind(i)) = CHC_metric(bot_CHpts_ind(IDX(i)));
end
end

function [qhullVolume, facets] = callqhull( points )
% Written by MAsadzadeh, University of Waterloo, June 04 2011

% qhull can be run with different options, see below. For now, the code only works with the following options:
options = 'FS Fv n ';
% If options changes, the output of qhull will change and user must modify
% the code to make sure that right info is extracted. 

%CALLQHULL calls the executable qhull which calculates the volume of convex
%hull of set of points and normal vectors of all the facets that create the
%convex hull. 
%% Prepare input file and command text to run qhull
num_points = size(points , 1);
dimensions = size(points , 2);
fid = fopen ('stdin.txt','w'); % The output of ghull
fprintf(fid,'%d \n',dimensions);
fprintf(fid,'%d \n',num_points);
for i = 1 : num_points
    fprintf(fid,'%f ',points(i , :));
    fprintf(fid,'\n');
end
fclose(fid);
command_cont = horzcat('qhull ', options, ' < stdin.txt TO stdout.txt');
dos(command_cont); % run the qhull and store the results in a text file
%% Read the output file line by line
fid = fopen('stdout.txt','r');
line{1} = fgetl(fid);
line{2} = fgetl(fid);
tmp = str2num(line{2});
qhullVolume = tmp(end);
line{3} = fgetl(fid);
facets.num = str2num(line{3});
facets.vertices = zeros(facets.num, dimensions);
for i = 3 + 1 : 3 + facets.num
    line{i} = fgetl(fid);
    tmp = str2num(line{i});
    num_pts = tmp(1);
    facets.vertices(i - 3, 1:num_pts) = tmp( 2 : end) + 1;
end
fgetl(fid);
fgetl(fid);
facets.norm = zeros(facets.num, dimensions);
for i = 3 + facets.num + 2 + 1 : 3 + facets.num + 2 + facets.num
    line{i} = fgetl(fid);
    tmp = str2num(line{i});
    facets.norm(i - (3 + facets.num + 2), :) = tmp( 1 : end - 1);
end
fclose all;
%% Options:
% FS - print sizes
% The first line consists of the number of integers ("0"). The second line
% consists of the number of reals ("2"), followed by the total facet area,
% and the total volume. Later versions of Qhull may produce additional
% integers or reals.   
% The total volume measures the volume of the intersection of the
% halfspaces defined by each facet. It is computed from the facet area.
% Both area and volume are approximations for non-simplicial facets. See
% option 'Fa ' for further notes. Option 'FA ' also computes the total area
% and volume. 

% Fv - print vertices for each facet
% The first line is the number of facets. Then each facet is printed, one
% per line. Each line is the number of vertices followed by the
% corresponding point ids. Vertices are listed in the order they were added
% to the hull (the last one added is the first listed).   
% Option 'i' also lists the vertices, but it orients facets by reversing
% the order of two vertices. Option 'i' triangulates non-simplicial, 4-d
% and higher facets by adding vertices for the centrums.

% n - print hyperplane normals with offsets 
% The first line is the dimension plus one. The second line is the number
% of facets. The remaining lines are the normals for each facet, one normal
% per line. The facet's offset follows its normal coefficients.  
% The normals point outward, i.e., the convex hull satisfies Ax <= -b where
% A is the matrix of coefficients and b is the vector of offsets. 
% If cdd output is specified ('FD'), Qhull prints the command line, the
% keyword "begin", the number of facets, the dimension (plus one), the
% keyword "real", and the normals for each facet. The facet's negative
% offset precedes its normal coefficients (i.e., if the origin is an
% interior point, the offset is positive). Qhull ends the output with the
% keyword "end".
end