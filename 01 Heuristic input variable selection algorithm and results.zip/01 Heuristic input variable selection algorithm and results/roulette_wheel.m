function Index = roulette_wheel(metric)
%% Roulette Wheel Selection Algorithm. A set of weights
% represents the probability of selection of each
% individual in a group of choices. It returns the index
% of the chosen individual.
% Usage example:
% example: Index = roulette_wheel ([1 5 3 15 8 1])
cumul_metric = cumsum(metric);
Probability = rand() * cumul_metric(end);
Index = find(cumul_metric >= Probability, 1, 'first');