function DDS(sinitial, its, fraction1, maxiter, obj_flag, Select_metric, out_plot,num_trials)

% Dynamically Dimensioned Search algorithm by Bryan Tolson.  Version 1.0.2  Oct 2005
% Coded as a MINIMZER but variable obj_flag converts a maximization
% objective to a minimization one without modifying the code below.  In other words, 
% specify obj_flag in DDS_inp.txt correctly and the code here does not need modification 
% for MAX or MIN objectives.
% this algorithm records all sampled solutions but only searches based on
% the best solution

% Modified my Masoud for PA-DDS Feb 2014:
% The modifications indlude:
%   1- The original perturbation which was designed for real-valued DVs is
%   modified to a mixed perturbation that can handle both real and discrete
%   valued decision variables.
%   2- The archiving strategy is added. For now all the non-dominated
%   solutions are archived.
%   3- The selection metric calculation function is added (RND: random
%   selection, CRD: Crowding Distance, HVC: Hypervolume selection)
%   4- The selection mechanism is added (This selection can be based on CD,
%   random, or ...)
%   5- Plotting the Pareto front with up to 6 objective functions.

global num_dec;
global S_min; % row vector of dec variable minimums - get from main program
global S_max; % row vector of dec variable maximums - get from main program

global num_objs; %added by masoud 09/05/08
global Discrete_flag;
global PF_set;
global objfunc_name; % function name that returns the objective function value
global Modeldir;

main_dir = pwd;
%% Variables Initialization
Jtest = zeros(1,num_objs);
stest = zeros(1,num_dec);
S_range = S_max - S_min;
PF_set = [inf * ones(1,num_objs) zeros(1,num_dec)];  %The first num_objs columns contain the objective functions of a 
            %solution and the other columns contain decision variables. 
%% Initialization
if its > 1   % its is the number of function evaluations to initialize the DDS algorithm solution
	ileft = maxiter - its; % use this to reduce number of fevals in DDS loop
    if ileft <= 0
        error('#Initialization samples >= Max # function evaluations.');
    end
    for i = 1 : its
        for j = 1 : num_dec
            if Discrete_flag(j) == 1
                stest(j) = randi([S_min(j),S_max(j)], 1); %MAsadzadeh March 21 2012 for new MATLAB
            else
                stest(j) = S_min(j) + S_range(j) * rand(1,1); % uniform random samples
            end
        end
        temp = [i,stest];
        temp = double(temp);
        save all_sol.mat temp -ascii
        cd(Modeldir);
        Jtest = feval(objfunc_name,stest);
        Jtest = obj_flag .* Jtest;
        cd(main_dir);
        temp = [i, obj_flag .* Jtest];
        temp = double(temp);
        save all_pts.mat temp -ascii
        if i == 1
            PF_set = [Jtest, stest]; %The first solution is obviously non-dominated
            temp = obj_flag .* Jtest;
            temp = double(temp);
            save nd_pts.mat temp -ascii
            temp = stest;
            temp = double(temp);
            save nd_sol.mat temp -ascii
        else %check whether the solution is dominated
            [PF_set, dominance_flag] = ND_check(PF_set, Jtest, stest);
            % dominance_flag = 1 : New solution dominated an archived solution
            %                = 0 : New solution is a new non-dominated one
            %                = -1: New solution is a dominated
            if dominance_flag ~= -1 % If new PF_set is changed
                temp = repmat(obj_flag, size(PF_set,1), 1) .* PF_set(:,1:num_objs);
                temp = double(temp);
                save nd_pts.mat temp -ascii
                temp = PF_set(:,num_objs+1:num_objs+num_dec);
                temp = double(temp);
                save nd_sol.mat temp -ascii
            end
%% Plotting Initial solutions. Turn off for long runs
            if out_plot == 1
                Plot_tradeoff(obj_flag, PF_set, [], [], objfunc_name, i, maxiter);
            end
        end
        
        if mod(i+its,1)==0
            str1=[num2str(num_trials),'results',num2str((i+its)/1),'.txt'];
            fid=fopen(str1,'w');
            fs1ij=PF_set(:,1:2);
            [mij,nij]=size(fs1ij);
             for iji=1:1:mij
               for jij=1:1:nij
                  if jij==nij
                    fprintf(fid,'%f\n',fs1ij(iji,jij));
                 else
                   fprintf(fid,'%f\t',fs1ij(iji,jij));
                  end
               end
             end
            sta=fclose(fid);
        end
        
        
        
        
        
        
    end
else  % --> its=1 --> using a set of user supplied initial solutions.
    for i = 1 : size(sinitial,1)
        if size(sinitial, 2) == (num_objs + num_dec)
            Jtest = obj_flag .* sinitial(i, 1 : num_objs);
            stest = sinitial(i, num_objs + 1 : num_objs + num_dec);
            its = 0;
        else
            stest = sinitial(i,:);  % get from the inputs
            cd(Modeldir);
            Jtest = feval(objfunc_name,stest); %Calculate obj func value
            Jtest = obj_flag .* Jtest;
            cd(main_dir);
            its = size(sinitial, 1);
        end
        if i == 1
            PF_set = [Jtest, stest];
            dominance_flag = 1;
            temp = obj_flag .* Jtest;
            temp = double(temp);
            save nd_pts.mat temp -ascii
            temp = stest;
            temp = double(temp);
            save nd_sol.mat temp -ascii
        else
            [PF_set, dominance_flag] = ND_check(PF_set,Jtest,stest);
            if dominance_flag ~= -1
                temp = repmat(obj_flag, size(PF_set,1), 1) .* PF_set(:,1:num_objs);
                temp = double(temp);
                save nd_pts.mat temp -ascii
                temp = PF_set(:,num_objs+1:num_objs+num_dec);
                temp = double(temp);
                save nd_sol.mat temp -ascii
            end
        end
        if out_plot == 1
            Plot_tradeoff(obj_flag, PF_set, [], [], objfunc_name, i, maxiter);
        end
    end
end
%% Main Loop of PA-DDS
ileft = maxiter - its;
%selection method: 0: Random (RND)
                  %1: Crowding Distance obj space (CRD)
                  %2: Hypervolume Contribution (HVC)
                  %3: Convex Hull Contribution (CHC)
switch Select_metric
    case {0}
        Metric = ones(size(PF_set, 1), 1);
    case {1}
        HVC; %CD_vec contains the crowded distance information
    case {2}
        Metric = HVC(PF_set(:, 1: num_objs));%For each point in the objective space information content is calculated as the difference in the convex hull with and without each solution
    case {3}
        Metric = CHC(PF_set(:, 1: num_objs));%For each point in the objective space information content is calculated as the difference in the convex hull with and without each solution
end
for i = 1 : ileft  % remaining F evals after initialization
    if mod(i,100) == 0
        fprintf('   iteration %d #Archived_sol %d\n', i, size(PF_set, 1));
    end
    if dominance_flag == -1 %if the last generated solution was dominated
        Index = roulette_wheel(Metric);
        sbest = PF_set(Index, num_objs + 1 : num_objs + num_dec);
        Jbest = PF_set(Index, 1 : num_objs);
    else %otherwise use the last generated solution
        Jbest = Jtest;
        sbest = stest;
    end
%% Plotting 
    if out_plot == 1
        Plot_tradeoff(obj_flag, PF_set, [], Jbest, objfunc_name, its + i, maxiter);
    end
%% DDS
    Pn = 1.0 - log(i) / log(ileft);
    dvn_count = 0; % counter for how many decision variables vary in neighbour
    randnums = rand(num_dec,1);
    stest = sbest;
    for j = 1 : num_dec
        if randnums(j) < Pn % then j th DV selected to vary in neighbour
            dvn_count = dvn_count + 1;
            new_value = neigh_value_mixed(sbest(j), S_min(j), S_max(j), fraction1, j);
            stest(j) = new_value; % change relevant dec var value in stest
        end
    end
    if dvn_count == 0 % no DVs selected at random, so select ONE
        dec_var = ceil(num_dec * rand(1,1)); % which dec var to modify for neighbour   
        new_value = neigh_value_mixed(sbest(dec_var), S_min(dec_var), S_max(dec_var), fraction1, dec_var);
        stest(dec_var) = new_value; % change relevant dec var value in stest
    end
    temp = [i, stest];
    temp = double(temp);
    save -append all_sol.mat temp -ascii
    cd(Modeldir);
    Jtest = feval(objfunc_name,stest);
    Jtest = obj_flag .* Jtest;
    cd(main_dir);
    temp = [i, obj_flag .* Jtest];
    temp = double(temp);
    save -append all_pts.mat temp -ascii

    num_imp = sum(Jtest <= Jbest);
    num_deg = sum(Jtest > Jbest);
    if num_imp == 0 && num_deg > 0 %New solution is dominated by its parent
        dominance_flag = -1;
    else % Do dominance check only if new solution is not diminated by its parent
        [PF_set, dominance_flag] = ND_check(PF_set, Jtest, stest);%added by masoud 09/05/08
        if dominance_flag ~= -1 % New solution is not dominated
            temp = repmat(obj_flag, size(PF_set,1), 1) .* PF_set(:,1:num_objs);
            temp = double(temp);
            save nd_pts.mat temp -ascii
            temp = PF_set(:, num_objs + 1 : num_objs + num_dec);
            temp = double(temp);
            save nd_sol.mat temp -ascii;
            switch Select_metric
                case {0}
                    Metric = ones(size(PF_set, 1), 1); % Random Selection
                case {1}
                    Metric = Crowd_dist(PF_set(:, 1: num_objs)); %crowded distance information
                case {2}
                    Metric = HVC(PF_set(:, 1: num_objs)); %Hypervolume Contribution
                case {3}
                    Metric = CHC(PF_set(:, 1: num_objs));%For each point in the objective space information content is calculated as the difference in the convex hull with and without each solution
            end
            if out_plot == 1
                Plot_tradeoff(obj_flag, PF_set, Jtest, Jbest, objfunc_name, its + i, maxiter);
            end
        end
    end
    if mod(i+its,1)==0
        str1=[num2str(num_trials),'results',num2str((i+its)/1),'.txt'];
        fid=fopen(str1,'w');
        fs1ij=PF_set(:,1:2);
        [mij,nij]=size(fs1ij);
         for iji=1:1:mij
           for jij=1:1:nij
              if jij==nij
                fprintf(fid,'%f\n',fs1ij(iji,jij));
             else
               fprintf(fid,'%f\t',fs1ij(iji,jij));
              end
           end
         end
        sta=fclose(fid);
    end
end % DDS function loop