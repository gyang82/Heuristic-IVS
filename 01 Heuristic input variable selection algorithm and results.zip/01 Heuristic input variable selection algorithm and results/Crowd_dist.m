function CDInd = Crowd_dist(points)
%This function calculates the Normalized Crowding Distance for each member
%or "points". Deb book p236
% The structure of PF_set is as follows:
% PF_set = [obj_1, obj_2, ... obj_m, DV_1, DV_2, ..., DV_n]
% e.g. CDInd = Crowd_dist([1 10; 2 9.8; 3 5; 4 4; 8 2; 10 1])

%% Normalize Objective Function Space
    max_f = max(points, [], 1);
    min_f = min(points, [], 1);
    ind = find(max_f == min_f);
    max_f(ind) = max_f(ind) + 1;
    MAX_f = repmat(max_f, size(points,1), 1);
    MIN_f = repmat(min_f, size(points,1), 1);
    points = (points - MIN_f) ./ (MAX_f - MIN_f);
%% Initializiation
    temp = [points, zeros(size(points,1),1), (1:size(points,1))']; % The last column is added to save the order of points because points are going to be sorted multiple times
    ij = size(temp, 2) - 1;
    endpointIndx = zeros(1, 2 * size(points,2));
%% Main Calculation
    if size(points,1) <= size(points,2) + 1 %Less than or equal # obj + 1 solutions are non-dominated
        temp(:,ij) = 1;  %The crowding distance is 1 for all archived solutions
        CDInd = temp(:, ij);
        return;
    else %More than 2 solutions are non-dominated 
        for i = 1 : size(points,2)
            temp = sortrows(temp,i);
            temp(1,ij) = temp(1,ij) + 2*(temp(2,i) - temp(1,i));
            temp(size(temp,1),ij) = temp(size(temp,1),ij) + 2*(temp(size(temp,1),i) - temp(size(temp,1)-1,i));
            for j = 2 : size(temp,1) - 1
                temp(j,ij) = temp(j,ij) +(temp(j+1,i) - temp(j-1,i));
            end
            endpointIndx(2 * (i-1) + 1) = temp(1, end);
            endpointIndx(2 * (i-1) + 2) = temp(end, end);
        end
    end
%% Endpoints of Pareto Front
    temp = sortrows(temp, size(temp,2)); % Sort points based on the last column to restore the original order of points in the archive 
    endpointIndx = unique(endpointIndx);
    non_endpointIndx = (1 : size(points,1))';
    non_endpointIndx(endpointIndx) = [];
    Y = points(endpointIndx, :);
    X = points(non_endpointIndx, :);
    IDX = dsearchn(X,Y); % Identify the closest point in the objective space to each endpoint
    if ~isempty(IDX)
        for i = 1 : length(endpointIndx)
            temp(endpointIndx(i), ij) = max([temp(endpointIndx(i), ij),temp(non_endpointIndx(IDX(i)), ij)]); % IF the closest point to the endpoint has a higher CD value, assign that to the endpoint; otherwise leave the CD value of the endpoint unchanged
        end
    end
    CDInd = temp(:, ij);
end