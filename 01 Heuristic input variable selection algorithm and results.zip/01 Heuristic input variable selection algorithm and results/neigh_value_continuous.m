function snew = neigh_value_continuous(s,s_min,s_max,fraction1)

% variables:
% s is a current SINGLE decision variable VALUE
% s_min is the min of variable s
% s_max is the max of variable s
s_range = s_max-s_min;
snew = s + randn(1,1) * fraction1 * s_range;
P_Abs_or_Ref = rand();
if snew < s_min % works for any pos or neg s_min
   snew = s_min;
elseif snew > s_max % works for any pos or neg s_max
   snew = s_max;
end

%   fraction1   Pmin        Pmax
%   <0.3        <0.0000     <0.0000 
%   0.4000      0.0000      0.0002
%   0.6000      0.0009      0.0124
%   0.8000      0.0124      0.0608
%   1.0000      0.0455      0.1336
%   1.2000      0.0956      0.2113

% above makes it difficult for neighbours to reach their absolute max and min 
% when fraction1 <0.3 but they can get close.  based on above, a
% fraction>1.2 does not seem to make very much sense since 1 of every 5 to 10
% samples of a parameter will result in visiting an exact endpoint.

