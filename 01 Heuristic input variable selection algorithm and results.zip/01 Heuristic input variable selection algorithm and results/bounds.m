function bounds
% This script reads from an external *.inp file the lower and upper bound
% for every parameter. User must provide this file in the model directory.

% The file name must be the same of objective function file name.

global S_name;
global S_min;
global S_max;
global Discrete_flag;
global objfunc_name; % function name that returns the objective function value
global Modeldir;

main_dir = pwd;
file = strcat(objfunc_name, '.inp');
cd(Modeldir);
fid = fopen(file, 'r');
cd(main_dir)
tmp = textscan(fid,'%s %f %f %f','headerlines',1);
fclose(fid);
S_name = tmp{:, 1};
S_min = cell2mat(tmp(:, 2));
S_max = cell2mat(tmp(:, 3));
Discrete_flag = cell2mat(tmp(:, 4));