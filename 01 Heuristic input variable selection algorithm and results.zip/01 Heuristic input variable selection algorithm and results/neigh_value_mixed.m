function snew = neigh_value_mixed(s,s_min,s_max,fraction1,j)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Created by B.Yung, April 2006
% Last modified by B.Yung, July 2006
% Purposes: run corresponding neighbour function for continuous and discrete 
%           decision variables  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global Discrete_flag; %Discrete flag vector is entered in ext_function.inp

if Discrete_flag(j)==0  % continuous variable:
    snew=neigh_value_continuous(s,s_min,s_max,fraction1);
else                    % discrete integer variable
    snew=neigh_value_discrete(s,s_min,s_max,fraction1);    
end