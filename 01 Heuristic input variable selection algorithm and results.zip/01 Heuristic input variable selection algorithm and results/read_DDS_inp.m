function [objfunc_name, runname, obj_flag, num_trials, iterations, user_seeds, fraction1, ...
        out_plot, ini_soln, ini_name, subdir, Select_metric] = read_DDS_inp(file_location)
% reads program inputs for Theory center DDS code.  Nov 04, Bryan Tolson

% Modified by MAsadzadeh 24/10/2013

%%% ***NEW ALGORITHM ***  change the algorithm input control text file NAME
%%% accordingly for your new algorithm
if isempty(file_location)
    fid = fopen('DDS_inp.txt','r');
else
    fid = fopen(strcat(file_location,'\DDS_inp.txt'),'r');
end

fgetl(fid); % nothing
fgetl(fid); % nothing
line3 = fgetl(fid); 
tmpInd  = strfind(line3, '%');
objfunc_name = strtrim(line3(1 : tmpInd - 1));

line4 = fgetl(fid);
tmpInd  = strfind(line4, '%');
runname = strtrim(line4(1 : tmpInd - 1));

line5 = fgetl(fid);
tmpInd  = strfind(line5, '%');
num_trials = str2double(strtrim(line5(1 : tmpInd - 1)));

line6 = fgetl(fid);
tmpInd  = strfind(line6, '%');
iterations = str2double(strtrim(line6(1 : tmpInd - 1)));

line7 = fgetl(fid);
tmpInd  = strfind(line7, '%');
randseed1 = str2double(strtrim(line7(1 : tmpInd - 1)));

line8 = fgetl(fid);
tmpInd  = strfind(line8, '%');
randseed2 = str2double(strtrim(line8(1 : tmpInd - 1)));

line9 = fgetl(fid);
tmpInd  = strfind(line9, '%');
out_plot = str2double(strtrim(line9(1 : tmpInd - 1)));

line10 = fgetl(fid);
tmpInd  = strfind(line10, '%');
ini_name = strtrim(deblank(line10(1 : tmpInd - 1)));
if isempty(ini_name)
    ini_soln = 0;
else
    ini_soln = 1;
end

line11 = fgetl(fid); 
tmpInd  = strfind(line11, '%');
subdir = strtrim(line11(1 : tmpInd - 1));

fgetl(fid); % nothing

fgetl(fid);
% user_comments = line13;  % DO NOT clean


%%% ***NEW ALGORITHM***
% starting on line 14 are Algorithm specific parameters.  Change the line reading code
% below so that you read your new algorithm specific parameters correctly:

line14 = fgetl(fid);
tmpInd  = strfind(line14, '%');
obj_flag = str2num(strtrim(line14(1 : tmpInd - 1)));

line15 = fgetl(fid);
tmpInd  = strfind(line15, '%');
fraction1 = str2double(strtrim(line15(1 : tmpInd - 1)));

line16 = fgetl(fid);% Added by MAsadzadeh to account for selection metric of non-dominated solutions
tmpInd  = strfind(line16, '%');
Select_metric = str2double(strtrim(line16(1 : tmpInd - 1)));
% done read
fclose(fid);

user_seeds=[randseed1; randseed2];