function Plot_tradeoff(obj_flag, PF_set, Jtest, Jbest, objfunc_name, i, maxiter)
% Works up to 2 objectives
figure(1)
h = gcf;
set(h, 'WindowStyle', 'docked');
plot(obj_flag(1) * PF_set(:,1), obj_flag(2) * PF_set(:,2),' k.')
if ~isempty(Jbest)
    hold on
    plot(obj_flag(1) * Jbest(1), obj_flag(2) * Jbest(:,2),'r*');
end
if ~isempty(Jtest)
    hold on
    plot(obj_flag(1)*Jtest(1),obj_flag(2)*Jtest(2),'go');
end
title([objfunc_name, ' Iteration = ' ,num2str(i),'/',num2str(maxiter)]);
grid on
xlabel('f_1'),ylabel('f_2')
hold off
end