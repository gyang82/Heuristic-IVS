function snew = neigh_value_discrete(s,s_min,s_max,fraction1)
% Created by B.Tolson and B.Yung, June 2006
% Modified by B. Tolson & M. Asadzadeh, Sept 2008
% Modification: 1- Boundary for reflection at (s_min-0.5) & (s_max+0.5)
%               2- Round the new value at the end of generation.
% select a RANDOM neighbouring integer value of a SINGLE decision variable
% discrete distribution is approximately normal 
% alternative to this appoach is reflecting triangular distribution (see Azadeh work)
% variables:
% s is a current SINGLE decision variable VALUE
% s_min is the min of variable s
% s_max is the max of variable s
% delta_s_min is the minimum perturbation size for each decision variable
    % equals [] if continuous DV (blank)
    % equals 1 if discrete integer valued DV
% snew is the neighboring VALUE of the decision variable
% fraction1 is the neighbourhood parameter (replaces V parameter~see notes)
%           It is defined as the ratio of the std deviation of the desired 
%           normal random number/s_range.  Eg:
%               std dev desired = fraction1 * s_range
%               for comparison:  variance (V) = (fraction1 * s_range)^2
% s_range is the range of the real variable (s_max-s_min)
s_range = s_max - s_min;
delta = randn(1,1) * fraction1 * s_range;
snew = s + delta;
P_Abs_or_Ref = rand();
if snew < s_min - 0.5 % works for any pos or neg s_min
    if P_Abs_or_Ref <= 0.5%with 50% chance reflect
        snew = (s_min-0.5) + ((s_min-0.5) - snew); 
    else %with 50% chance absorb
        snew = s_min;
    end
        % if reflection goes past (s_max+0.5) then value should be s_min since without reflection
        % the approach goes way past lower bound.  This keeps X close to lower bound when X current
        % is close to lower bound:
        if snew > s_max + 0.5
            snew = s_min;
        end        
elseif snew > s_max + 0.5 % works for any pos or neg s_max
    if P_Abs_or_Ref <= 0.5%with 50% chance reflect
        snew = (s_max+0.5) - (snew-(s_max+0.5));     
    else %with 50% chance absorb
        snew = s_max;
    end
        % if reflection goes past (s_min-0.5) then value should be s_max for same reasons as above
    if snew < s_min - 0.5
        snew = s_max;
    end
end
snew=round(snew); %New value must be integer
if snew==s %pick a number between s_max and s_min by a Uniform distribution
    sample = s_min-1+ceil((s_max-s_min)*rand(1,1)); % last term gives range = # options - 1.  First terms shift to allow min value
    if sample<s
        snew=sample;
    else  % must increment option number by one
        snew=sample+1;
    end
end